<?php
/**
 * Created by PhpStorm.
 * User: AM-PC
 * Date: 10/3/2017
 * Time: 4:29 PM
 */

namespace App\Http\Controllers;


class PagesController extends Controller
{

    public function getIndex(){
        return view('pages.welcome');
    }
    public function getAbout(){
        return view('pages.about');

    }
    public function getContact(){
        return view('pages.contact');
    }


}